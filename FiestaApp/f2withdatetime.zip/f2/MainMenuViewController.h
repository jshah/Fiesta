//
//  MainMenuViewController.h
//  f2
//
//  Created by Meenal Tambe on 3/13/12.
//  Copyright (c) 2012 University of California, Davis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainMenuViewController : UIViewController

@end
