//
//  CreateEventViewController.m
//  f2
//
//  Created by Meenal Tambe on 3/13/12.
//  Copyright (c) 2012 University of California, Davis. All rights reserved.
//

#import "CreateEventViewController.h"

@implementation CreateEventViewController
@synthesize title;
@synthesize address;
@synthesize date;
@synthesize description;
@synthesize currentEvent;
@synthesize flag;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    //[self setresults:nil];
    [self setTitle:nil];
    [self setAddress:nil];
    [self setDate:nil];
    [self setDescription:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)time:(id)sender {
    UISegmentedControl *time = sender;
    if( time.selectedSegmentIndex == 0) {
        flag = 0;
        /*UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Enter the Date"
                                                          message:nil
                                                         delegate:self 
                                                cancelButtonTitle:@"Cancel" 
                                                otherButtonTitles:@"OK", nil];
        
        [message setAlertViewStyle:UIAlertViewStylePlainTextInput];
        
        [message show];*/
        UITextField *textField; 
        
        UIAlertView *prompt2 = [[UIAlertView alloc] initWithTitle:@"Enter Date:"               
                                                         message:@"MEENALDRINKSLOTSACOFFEE" //I need this for positioning lol         
                                                        delegate:nil              
                                               cancelButtonTitle:@"Cancel"             
                                               otherButtonTitles:@"OK", nil];
        
        textField = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 50.0, 260.0, 25.0)];  
        [textField setBackgroundColor:[UIColor orangeColor]]; 
        [textField setPlaceholder:@"date"];
        [prompt2 addSubview:textField];
        [prompt2 show];    
        [textField becomeFirstResponder];
    
        //NSLog(@"First Segment Selected");
    }
    if( time.selectedSegmentIndex == 1) {
        flag = 1;
      /*  UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Enter the Time"
                                                          message:nil
                                                         delegate:self 
                                                cancelButtonTitle:@"Cancel" 
                                                otherButtonTitles:@"OK", nil];
        
        [message setAlertViewStyle:UIAlertViewStylePlainTextInput];
        
        [message show];
        //NSLog(@"Second Segment Selected");
    }*/
        UITextField *textField2;
        
        UIAlertView *prompt = [[UIAlertView alloc] initWithTitle:@"Enter Time:"               
                                                        message:@"WTFISINTHISCOFFEE" //I need this for poisitioning lol         
                                                        delegate:nil              
                                               cancelButtonTitle:@"Cancel"             
                                               otherButtonTitles:@"OK", nil];
                               
        textField2 = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 50.0, 260.0, 25.0)];  
        [textField2 setBackgroundColor:[UIColor orangeColor]]; 
        [textField2 setPlaceholder:@"time"];
        [prompt addSubview:textField2];
        [prompt show];    
        [textField2 becomeFirstResponder];
                               }
    
    
        
}

- (IBAction)hidekeyboard:(id)sender {
    [self.title resignFirstResponder];
    [self.address resignFirstResponder];
    [self.description resignFirstResponder];
}

- (IBAction)store:(id)sender {
    
    NSString *csvLine=[NSString stringWithFormat:@"%@ \n %@ \n %@ \n",
                       self.title.text,
                       self.address.text,
                       self.description.text];
    
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(
                                                            NSDocumentDirectory,
                                                            NSUserDomainMask, YES) 
                        objectAtIndex: 0];

    
    NSString *storeevent = [docDir 
                            stringByAppendingPathComponent:
                            @"results2.csv"];
    
    if  (![[NSFileManager defaultManager] fileExistsAtPath:storeevent]) {
        [[NSFileManager defaultManager] 
         createFileAtPath:storeevent contents:nil attributes:nil];
    }
    
    NSFileHandle *fileHandle = [NSFileHandle 
                                fileHandleForUpdatingAtPath:storeevent];
    [fileHandle seekToEndOfFile];
    [fileHandle writeData:[csvLine 
                           dataUsingEncoding:NSUTF8StringEncoding]];
    [fileHandle closeFile];

}

-(IBAction)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender 
{
	MenuViewAppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
	
    currentEvent = [PFObject objectWithClassName: @"FiestaEvent"];
    [currentEvent setObject: self.title.text forKey: @"Title"];
    [currentEvent setObject: self.address.text forKey: @"Address"];
    [currentEvent setObject: self.description.text forKey: @"Description"];
	[currentEvent setObject: [NSNumber numberWithInt:[appDelegate getCount]] forKey:@"Count"];
	
	[appDelegate increaseCount];
	
	[currentEvent saveInBackground];
	[appDelegate setFieldValue:currentEvent];
    
    NSLog(@"CurrentEvent ID: %@", [appDelegate getFieldValueAtPos]);
	NSLog(@"CurrentEvent: %@", [currentEvent objectForKey:@"Title"]);
    
}


@end
