//
//  main.m
//  f2
//
//  Created by Meenal Tambe on 3/8/12.
//  Copyright (c) 2012 University of California, Davis. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MenuViewAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MenuViewAppDelegate class]));
    }
}
