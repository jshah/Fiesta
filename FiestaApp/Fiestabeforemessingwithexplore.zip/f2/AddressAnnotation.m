//
//  AddressAnnotation.m
//  f2
//
//  Created by Kabir Sikand on 3/18/12.
//  Copyright (c) 2012 University of California, Davis. All rights reserved.
//

#import "AddressAnnotation.h"

@implementation AddressAnnotation
@synthesize coordinate;

- (NSString *)subtitle{
	return nil;
}

- (NSString *)title{
	return nil;
}

-(id)initWithCoordinate:(CLLocationCoordinate2D) c{
	coordinate=c;
	return self;
}

@end
